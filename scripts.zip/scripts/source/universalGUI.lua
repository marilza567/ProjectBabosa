-- Farewell Infortality.
-- Version: 2.82
-- Instances:
local GUITHING = Instance.new("ScreenGui")
local makeinvisble = Instance.new("Frame")
local r15gui = Instance.new("Frame")
local rainbow1 = Instance.new("Frame")
local rainbow2 = Instance.new("Frame")
local title1 = Instance.new("TextLabel")
local blockhead = Instance.new("TextButton")
local creeperR15 = Instance.new("TextButton")
local removewaist = Instance.new("TextButton")
local drophats = Instance.new("TextButton")
local blockhats = Instance.new("TextButton")
local shattervest = Instance.new("TextButton")
local animationgui = Instance.new("TextButton")
local invisble = Instance.new("TextButton")
local r6gui = Instance.new("Frame")
local rainbow3 = Instance.new("Frame")
local rainbow4 = Instance.new("Frame")
local title2 = Instance.new("TextLabel")
local creeperR6 = Instance.new("TextButton")
local blockhead1 = Instance.new("TextButton")
local drophats1 = Instance.new("TextButton")
local blockhats1 = Instance.new("TextButton")
local animationgui1 = Instance.new("TextButton")
local shattervest1 = Instance.new("TextButton")
local gabx = Instance.new("TextButton")
local toolsgui = Instance.new("Frame")
local rainbow5 = Instance.new("Frame")
local rainbow6 = Instance.new("Frame")
local title3 = Instance.new("TextLabel")
local savetools = Instance.new("TextButton")
local loadtools = Instance.new("TextButton")
local othersgui = Instance.new("Frame")
local rainbow8 = Instance.new("Frame")
local rainbow7 = Instance.new("Frame")
local title4 = Instance.new("TextLabel")
local fathomhub = Instance.new("TextButton")
local legacyhub = Instance.new("TextButton")
local vehiclegui = Instance.new("TextButton")
local aimbotctrl = Instance.new("TextButton")
local aimboth = Instance.new("TextButton")
local antiafk = Instance.new("TextButton")
local phonegui = Instance.new("TextButton")
local survivorgui = Instance.new("TextButton")
--Properties:
GUITHING.Name = "GUITHING"
GUITHING.Parent = game.CoreGui

makeinvisble.Name = "makeinvisble :)"
makeinvisble.Parent = GUITHING
makeinvisble.BackgroundColor3 = Color3.new(1, 1, 1)
makeinvisble.BackgroundTransparency = 0.60000002384186
makeinvisble.Size = UDim2.new(0, 1133, 0, 514)
makeinvisble.Visible = false

r15gui.Name = "r15gui"
r15gui.Parent = makeinvisble
r15gui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
r15gui.BorderSizePixel = 0
r15gui.Position = UDim2.new(0.0260384381, 0, 0.0297973789, 0)
r15gui.Size = UDim2.new(0, 223, 0, 25)

rainbow1.Name = "rainbow1"
rainbow1.Parent = r15gui
rainbow1.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow1.BorderColor3 = Color3.new(0.282353, 0.282353, 0.282353)
rainbow1.BorderSizePixel = 5
rainbow1.Position = UDim2.new(0.0401113182, 0, 0.981453836, 0)
rainbow1.Size = UDim2.new(0, 203, 0, 379)

rainbow2.Name = "rainbow2"
rainbow2.Parent = r15gui
rainbow2.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow2.BorderSizePixel = 0
rainbow2.Position = UDim2.new(-0.000247425021, 0, -0.258545846, 0)
rainbow2.Size = UDim2.new(0, 223, 0, 6)

title1.Name = "title1"
title1.Parent = r15gui
title1.BackgroundColor3 = Color3.new(1, 1, 1)
title1.BackgroundTransparency = 1
title1.Position = UDim2.new(0.0538116582, 0, 0, 0)
title1.Size = UDim2.new(0, 200, 0, 24)
title1.Font = Enum.Font.SourceSansLight
title1.Text = "R15 Scripts"
title1.TextColor3 = Color3.new(1, 1, 1)
title1.TextScaled = true
title1.TextSize = 14
title1.TextWrapped = true

blockhead.Name = "blockhead"
blockhead.Parent = r15gui
blockhead.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
blockhead.BorderSizePixel = 0
blockhead.Position = UDim2.new(0.107623316, 0, 1.60000002, 0)
blockhead.Size = UDim2.new(0, 172, 0, 27)
blockhead.Font = Enum.Font.SourceSansLight
blockhead.Text = "Blockhead"
blockhead.TextColor3 = Color3.new(1, 1, 1)
blockhead.TextScaled = true
blockhead.TextSize = 14
blockhead.TextWrapped = true

creeperR15.Name = "creeperR15"
creeperR15.Parent = r15gui
creeperR15.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
creeperR15.BorderSizePixel = 0
creeperR15.Position = UDim2.new(0.11210762, 0, 3.51999998, 0)
creeperR15.Size = UDim2.new(0, 172, 0, 27)
creeperR15.Font = Enum.Font.SourceSansLight
creeperR15.Text = "Creepa.. Aw Man"
creeperR15.TextColor3 = Color3.new(1, 1, 1)
creeperR15.TextScaled = true
creeperR15.TextSize = 14
creeperR15.TextWrapped = true

removewaist.Name = "removewaist"
removewaist.Parent = r15gui
removewaist.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
removewaist.BorderSizePixel = 0
removewaist.Position = UDim2.new(0.107623316, 0, 5.31999969, 0)
removewaist.Size = UDim2.new(0, 172, 0, 27)
removewaist.Font = Enum.Font.SourceSansLight
removewaist.Text = "Remove Waist"
removewaist.TextColor3 = Color3.new(1, 1, 1)
removewaist.TextScaled = true
removewaist.TextSize = 14
removewaist.TextWrapped = true

drophats.Name = "drophats"
drophats.Parent = r15gui
drophats.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
drophats.BorderSizePixel = 0
drophats.Position = UDim2.new(0.107623316, 0, 7.19999981, 0)
drophats.Size = UDim2.new(0, 172, 0, 27)
drophats.Font = Enum.Font.SourceSansLight
drophats.Text = "Drop Hats"
drophats.TextColor3 = Color3.new(1, 1, 1)
drophats.TextScaled = true
drophats.TextSize = 14
drophats.TextWrapped = true

blockhats.Name = "blockhats"
blockhats.Parent = r15gui
blockhats.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
blockhats.BorderSizePixel = 0
blockhats.Position = UDim2.new(0.107623316, 0, 9.11999989, 0)
blockhats.Size = UDim2.new(0, 172, 0, 27)
blockhats.Font = Enum.Font.SourceSansLight
blockhats.Text = "Block Hats"
blockhats.TextColor3 = Color3.new(1, 1, 1)
blockhats.TextScaled = true
blockhats.TextSize = 14
blockhats.TextWrapped = true

shattervest.Name = "shattervest"
shattervest.Parent = r15gui
shattervest.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
shattervest.BorderSizePixel = 0
shattervest.Position = UDim2.new(0.107623316, 0, 11.0799999, 0)
shattervest.Size = UDim2.new(0, 172, 0, 27)
shattervest.Font = Enum.Font.SourceSansLight
shattervest.Text = "Shattervest Admin"
shattervest.TextColor3 = Color3.new(1, 1, 1)
shattervest.TextSize = 25
shattervest.TextWrapped = true

animationgui.Name = "animationgui"
animationgui.Parent = r15gui
animationgui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
animationgui.BorderSizePixel = 0
animationgui.Position = UDim2.new(0.107623316, 0, 12.8400002, 0)
animationgui.Size = UDim2.new(0, 172, 0, 27)
animationgui.Font = Enum.Font.SourceSansLight
animationgui.Text = "Animation GUI"
animationgui.TextColor3 = Color3.new(1, 1, 1)
animationgui.TextSize = 25
animationgui.TextWrapped = true

invisble.Name = "invisble"
invisble.Parent = r15gui
invisble.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
invisble.BorderSizePixel = 0
invisble.Position = UDim2.new(0.107623316, 0, 14.5200005, 0)
invisble.Size = UDim2.new(0, 172, 0, 27)
invisble.Font = Enum.Font.SourceSansLight
invisble.Text = "Complete Invisble"
invisble.TextColor3 = Color3.new(1, 1, 1)
invisble.TextSize = 25
invisble.TextWrapped = true

r6gui.Name = "r6gui"
r6gui.Parent = makeinvisble
r6gui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
r6gui.BorderSizePixel = 0
r6gui.Position = UDim2.new(0.235393807, 0, 0.0297973789, 0)
r6gui.Size = UDim2.new(0, 223, 0, 25)

rainbow3.Name = "rainbow3"
rainbow3.Parent = r6gui
rainbow3.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow3.BorderColor3 = Color3.new(0.282353, 0.282353, 0.282353)
rainbow3.BorderSizePixel = 5
rainbow3.Position = UDim2.new(0.0445956253, 0, 0.981453836, 0)
rainbow3.Size = UDim2.new(0, 203, 0, 339)

rainbow4.Name = "rainbow4"
rainbow4.Parent = r6gui
rainbow4.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow4.BorderSizePixel = 0
rainbow4.Position = UDim2.new(-0.000247425021, 0, -0.258545846, 0)
rainbow4.Size = UDim2.new(0, 223, 0, 6)

title2.Name = "title2"
title2.Parent = r6gui
title2.BackgroundColor3 = Color3.new(1, 1, 1)
title2.BackgroundTransparency = 1
title2.Position = UDim2.new(0.0538116582, 0, 0.0399999991, 0)
title2.Size = UDim2.new(0, 200, 0, 24)
title2.Font = Enum.Font.SourceSansLight
title2.Text = "R6 Scripts"
title2.TextColor3 = Color3.new(1, 1, 1)
title2.TextScaled = true
title2.TextSize = 14
title2.TextWrapped = true

creeperR6.Name = "creeperR6"
creeperR6.Parent = r6gui
creeperR6.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
creeperR6.BorderSizePixel = 0
creeperR6.Position = UDim2.new(0.11659193, 0, 1.60000002, 0)
creeperR6.Size = UDim2.new(0, 172, 0, 27)
creeperR6.Font = Enum.Font.SourceSansLight
creeperR6.Text = "Creepa.. Aw Man"
creeperR6.TextColor3 = Color3.new(1, 1, 1)
creeperR6.TextScaled = true
creeperR6.TextSize = 14
creeperR6.TextWrapped = true

blockhead1.Name = "blockhead1"
blockhead1.Parent = r6gui
blockhead1.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
blockhead1.BorderSizePixel = 0
blockhead1.Position = UDim2.new(0.11659193, 0, 3.51999998, 0)
blockhead1.Size = UDim2.new(0, 172, 0, 27)
blockhead1.Font = Enum.Font.SourceSansLight
blockhead1.Text = "Blockhead"
blockhead1.TextColor3 = Color3.new(1, 1, 1)
blockhead1.TextScaled = true
blockhead1.TextSize = 14
blockhead1.TextWrapped = true

drophats1.Name = "drophats1"
drophats1.Parent = r6gui
drophats1.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
drophats1.BorderSizePixel = 0
drophats1.Position = UDim2.new(0.112107627, 0, 5.32000017, 0)
drophats1.Size = UDim2.new(0, 172, 0, 27)
drophats1.Font = Enum.Font.SourceSansLight
drophats1.Text = "Drop Hats"
drophats1.TextColor3 = Color3.new(1, 1, 1)
drophats1.TextScaled = true
drophats1.TextSize = 14
drophats1.TextWrapped = true

blockhats1.Name = "blockhats1"
blockhats1.Parent = r6gui
blockhats1.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
blockhats1.BorderSizePixel = 0
blockhats1.Position = UDim2.new(0.112107627, 0, 7.20000029, 0)
blockhats1.Size = UDim2.new(0, 172, 0, 27)
blockhats1.Font = Enum.Font.SourceSansLight
blockhats1.Text = "Block Hats"
blockhats1.TextColor3 = Color3.new(1, 1, 1)
blockhats1.TextScaled = true
blockhats1.TextSize = 14
blockhats1.TextWrapped = true

animationgui1.Name = "animationgui1"
animationgui1.Parent = r6gui
animationgui1.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
animationgui1.BorderSizePixel = 0
animationgui1.Position = UDim2.new(0.112107627, 0, 9.11999989, 0)
animationgui1.Size = UDim2.new(0, 172, 0, 27)
animationgui1.Font = Enum.Font.SourceSansLight
animationgui1.Text = "Animation GUI"
animationgui1.TextColor3 = Color3.new(1, 1, 1)
animationgui1.TextScaled = true
animationgui1.TextSize = 14
animationgui1.TextWrapped = true

shattervest1.Name = "shattervest1"
shattervest1.Parent = r6gui
shattervest1.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
shattervest1.BorderSizePixel = 0
shattervest1.Position = UDim2.new(0.112107627, 0, 11.0799999, 0)
shattervest1.Size = UDim2.new(0, 172, 0, 27)
shattervest1.Font = Enum.Font.SourceSansLight
shattervest1.Text = "Shattervest"
shattervest1.TextColor3 = Color3.new(1, 1, 1)
shattervest1.TextScaled = true
shattervest1.TextSize = 14
shattervest1.TextWrapped = true

gabx.Name = "gabx"
gabx.Parent = r6gui
gabx.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
gabx.BorderSizePixel = 0
gabx.Position = UDim2.new(0.112107627, 0, 12.8400002, 0)
gabx.Size = UDim2.new(0, 172, 0, 27)
gabx.Font = Enum.Font.SourceSansLight
gabx.Text = "OP FLING GUI"
gabx.TextColor3 = Color3.new(1, 1, 1)
gabx.TextScaled = true
gabx.TextSize = 14
gabx.TextWrapped = true

toolsgui.Name = "toolsgui"
toolsgui.Parent = makeinvisble
toolsgui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
toolsgui.BorderSizePixel = 0
toolsgui.Position = UDim2.new(0.445295811, 0, 0.0305510089, 0)
toolsgui.Size = UDim2.new(0, 223, 0, 25)

rainbow5.Name = "rainbow5"
rainbow5.Parent = toolsgui
rainbow5.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow5.BorderColor3 = Color3.new(0.282353, 0.282353, 0.282353)
rainbow5.BorderSizePixel = 5
rainbow5.Position = UDim2.new(0.0401113182, 0, 0.981453836, 0)
rainbow5.Size = UDim2.new(0, 203, 0, 109)

rainbow6.Name = "rainbow6"
rainbow6.Parent = toolsgui
rainbow6.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow6.BorderSizePixel = 0
rainbow6.Position = UDim2.new(-0.000247425021, 0, -0.258545846, 0)
rainbow6.Size = UDim2.new(0, 223, 0, 6)

title3.Name = "title3"
title3.Parent = toolsgui
title3.BackgroundColor3 = Color3.new(1, 1, 1)
title3.BackgroundTransparency = 1
title3.Position = UDim2.new(0.0538116582, 0, 0, 0)
title3.Size = UDim2.new(0, 200, 0, 24)
title3.Font = Enum.Font.SourceSansLight
title3.Text = "Save/Load Tools"
title3.TextColor3 = Color3.new(1, 1, 1)
title3.TextScaled = true
title3.TextSize = 14
title3.TextWrapped = true

savetools.Name = "savetools"
savetools.Parent = toolsgui
savetools.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
savetools.BorderSizePixel = 0
savetools.Position = UDim2.new(0.107623316, 0, 1.63999987, 0)
savetools.Size = UDim2.new(0, 172, 0, 27)
savetools.Font = Enum.Font.SourceSansLight
savetools.Text = "Save Tools"
savetools.TextColor3 = Color3.new(1, 1, 1)
savetools.TextScaled = true
savetools.TextSize = 14
savetools.TextWrapped = true

loadtools.Name = "loadtools"
loadtools.Parent = toolsgui
loadtools.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
loadtools.BorderSizePixel = 0
loadtools.Position = UDim2.new(0.107623316, 0, 3.55999994, 0)
loadtools.Size = UDim2.new(0, 172, 0, 27)
loadtools.Font = Enum.Font.SourceSansLight
loadtools.Text = "Load Tools"
loadtools.TextColor3 = Color3.new(1, 1, 1)
loadtools.TextScaled = true
loadtools.TextSize = 14
loadtools.TextWrapped = true

othersgui.Name = "othersgui"
othersgui.Parent = makeinvisble
othersgui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
othersgui.BorderSizePixel = 0
othersgui.Position = UDim2.new(0.657109678, 0, 0.027413588, 0)
othersgui.Size = UDim2.new(0, 223, 0, 25)

rainbow8.Name = "rainbow8"
rainbow8.Parent = othersgui
rainbow8.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow8.BorderColor3 = Color3.new(0.282353, 0.282353, 0.282353)
rainbow8.BorderSizePixel = 5
rainbow8.Position = UDim2.new(0.0401113182, 0, 0.981453836, 0)
rainbow8.Size = UDim2.new(0, 203, 0, 381)

rainbow7.Name = "rainbow7"
rainbow7.Parent = othersgui
rainbow7.BackgroundColor3 = Color3.new(1, 1, 1)
rainbow7.BorderSizePixel = 0
rainbow7.Position = UDim2.new(-0.000247425021, 0, -0.258545846, 0)
rainbow7.Size = UDim2.new(0, 223, 0, 6)

title4.Name = "title4"
title4.Parent = othersgui
title4.BackgroundColor3 = Color3.new(1, 1, 1)
title4.BackgroundTransparency = 1
title4.Position = UDim2.new(0.0538116582, 0, 0, 0)
title4.Size = UDim2.new(0, 200, 0, 24)
title4.Font = Enum.Font.SourceSansLight
title4.Text = "Other Script/GUI"s"
title4.TextColor3 = Color3.new(1, 1, 1)
title4.TextScaled = true
title4.TextSize = 14
title4.TextWrapped = true

fathomhub.Name = "fathomhub"
fathomhub.Parent = othersgui
fathomhub.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
fathomhub.BorderSizePixel = 0
fathomhub.Position = UDim2.new(0.107623316, 0, 1.63999987, 0)
fathomhub.Size = UDim2.new(0, 172, 0, 27)
fathomhub.Font = Enum.Font.SourceSansLight
fathomhub.Text = "Fathom HUB"
fathomhub.TextColor3 = Color3.new(1, 1, 1)
fathomhub.TextScaled = true
fathomhub.TextSize = 14
fathomhub.TextWrapped = true

legacyhub.Name = "legacyhub"
legacyhub.Parent = othersgui
legacyhub.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
legacyhub.BorderSizePixel = 0
legacyhub.Position = UDim2.new(0.107623316, 0, 3.55999994, 0)
legacyhub.Size = UDim2.new(0, 172, 0, 27)
legacyhub.Font = Enum.Font.SourceSansLight
legacyhub.Text = "Legacy HUB"
legacyhub.TextColor3 = Color3.new(1, 1, 1)
legacyhub.TextScaled = true
legacyhub.TextSize = 14
legacyhub.TextWrapped = true

vehiclegui.Name = "vehiclegui"
vehiclegui.Parent = othersgui
vehiclegui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
vehiclegui.BorderSizePixel = 0
vehiclegui.Position = UDim2.new(0.11659193, 0, 5.35999966, 0)
vehiclegui.Size = UDim2.new(0, 172, 0, 27)
vehiclegui.Font = Enum.Font.SourceSansLight
vehiclegui.Text = "Vehicle Simulator"
vehiclegui.TextColor3 = Color3.new(1, 1, 1)
vehiclegui.TextScaled = true
vehiclegui.TextSize = 14
vehiclegui.TextWrapped = true

aimbotctrl.Name = "aimbotctrl"
aimbotctrl.Parent = othersgui
aimbotctrl.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
aimbotctrl.BorderSizePixel = 0
aimbotctrl.Position = UDim2.new(0.107623324, 0, 7.27999973, 0)
aimbotctrl.Size = UDim2.new(0, 172, 0, 27)
aimbotctrl.Font = Enum.Font.SourceSansLight
aimbotctrl.Text = "Aimbot And ESP (CTRL)"
aimbotctrl.TextColor3 = Color3.new(1, 1, 1)
aimbotctrl.TextScaled = true
aimbotctrl.TextSize = 14
aimbotctrl.TextWrapped = true

aimboth.Name = "aimboth"
aimboth.Parent = othersgui
aimboth.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
aimboth.BorderSizePixel = 0
aimboth.Position = UDim2.new(0.107623324, 0, 9.19999981, 0)
aimboth.Size = UDim2.new(0, 172, 0, 27)
aimboth.Font = Enum.Font.SourceSansLight
aimboth.Text = "Aimbot And ESP (H)"
aimboth.TextColor3 = Color3.new(1, 1, 1)
aimboth.TextScaled = true
aimboth.TextSize = 14
aimboth.TextWrapped = true

antiafk.Name = "antiafk"
antiafk.Parent = othersgui
antiafk.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
antiafk.BorderSizePixel = 0
antiafk.Position = UDim2.new(0.107623324, 0, 11.1599998, 0)
antiafk.Size = UDim2.new(0, 172, 0, 27)
antiafk.Font = Enum.Font.SourceSansLight
antiafk.Text = "Anti AFK"
antiafk.TextColor3 = Color3.new(1, 1, 1)
antiafk.TextScaled = true
antiafk.TextSize = 14
antiafk.TextWrapped = true

phonegui.Name = "phonegui"
phonegui.Parent = othersgui
phonegui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
phonegui.BorderSizePixel = 0
phonegui.Position = UDim2.new(0.112107627, 0, 12.9200001, 0)
phonegui.Size = UDim2.new(0, 172, 0, 27)
phonegui.Font = Enum.Font.SourceSansLight
phonegui.Text = "Phone GUI"
phonegui.TextColor3 = Color3.new(1, 1, 1)
phonegui.TextScaled = true
phonegui.TextSize = 14
phonegui.TextWrapped = true

survivorgui.Name = "survivorgui"
survivorgui.Parent = othersgui
survivorgui.BackgroundColor3 = Color3.new(0.282353, 0.282353, 0.282353)
survivorgui.BorderSizePixel = 0
survivorgui.Position = UDim2.new(0.107623324, 0, 14.6000004, 0)
survivorgui.Size = UDim2.new(0, 172, 0, 27)
survivorgui.Font = Enum.Font.SourceSansLight
survivorgui.Text = "Survivor GUI"
survivorgui.TextColor3 = Color3.new(1, 1, 1)
survivorgui.TextScaled = true
survivorgui.TextSize = 14
survivorgui.TextWrapped = true

-- Scripts:


print("did not even past first test :)")

aimbotctrl.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/2kbyfrn5", true))()
end)

aimboth.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/xB92ES44", true))()
end)

antiafk.MouseButton1Click:connect(function()
	local VirtualUser=game:service"VirtualUser"
game:service"Players".LocalPlayer.Idled:connect(function()
VirtualUser:CaptureController()
VirtualUser:ClickButton2(Vector2.new())
end)
end)

fathomhub.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/UmhaEvTT",true))()
end)

legacyhub.MouseButton1Click:connect(function()
	loadstring(game:GetObjects("rbxassetid://1683559539")[1].Source)()
end)

phonegui.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/nScPDiay", true))()
end)

survivorgui.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/1ZyLGHZu", true))()
end)

vehiclegui.MouseButton1Click:connect(function()
	 loadstring(game:HttpGet(("https://pastebin.com/raw/nFjsc1LT"),true))()
end)

animationgui.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/uUR6pFVv", true))()
end)

animationgui1.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/uUR6pFVv", true))()
end)

blockhats.MouseButton1Click:connect(function()
	for _,v in pairs(game.Players.LocalPlayer:GetChildren()) do
if (v:IsA("Tool")) then
v.Parent = game.Players.LocalPlayer.Backpack
end
end
end)

blockhats1.MouseButton1Click:connect(function()
	for _,v in pairs(game.Players.LocalPlayer:GetChildren()) do
if (v:IsA("Tool")) then
v.Parent = game.Players.LocalPlayer.Backpack
end
end
end)

blockhead.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Head.Mesh:destroy()
end)

blockhead1.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Head.Mesh:destroy()
end)

creeperR15.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Head.Mesh:destroy()
function doo(limb, pos)
limb:BreakJoints()
local velocity = Instance.new("RocketPropulsion", limb)
velocity.CartoonFactor = 0
velocity.MaxSpeed = 30
velocity.MaxThrust = 9999
velocity.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
velocity.Target = game.Players.LocalPlayer.Character.UpperTorso
velocity.TargetOffset = pos
velocity:fire()
local b = Instance.new("BodyGyro", limb)
end
while wait() do
doo(game.Players.LocalPlayer.Character["LeftUpperArm"], Vector3.new(-0.5,-2,-1))
doo(game.Players.LocalPlayer.Character["RightUpperArm"], Vector3.new(0.5,-2,-1))
doo(game.Players.LocalPlayer.Character["LeftUpperLeg"], Vector3.new(-0.5,-2,1))
doo(game.Players.LocalPlayer.Character["RightUpperLeg"], Vector3.new(0.5,-2,1))
end
end)

creeperR6.MouseButton1Click:connect(function()
	game.Players.LocalPlayer.Character.Head.Mesh:destroy()
function doo(limb, pos)
limb:BreakJoints()
local velocity = Instance.new("RocketPropulsion", limb)
velocity.CartoonFactor = 0
velocity.MaxSpeed = 30
velocity.MaxThrust = 9999
velocity.MaxTorque = Vector3.new(math.huge,math.huge,math.huge)
velocity.Target = game.Players.LocalPlayer.Character.Torso
velocity.TargetOffset = pos
velocity:fire()
local b = Instance.new("BodyGyro", limb)
end
while wait() do
doo(game.Players.LocalPlayer.Character["Left Arm"], Vector3.new(-0.5,-2,-1))
doo(game.Players.LocalPlayer.Character["Right Arm"], Vector3.new(0.5,-2,-1))
doo(game.Players.LocalPlayer.Character["Left Leg"], Vector3.new(-0.5,-2,1))
doo(game.Players.LocalPlayer.Character["Right Leg"], Vector3.new(0.5,-2,1))
end
end)

drophats.MouseButton1Click:connect(function()
	game.Players.LocalPlayer:GetMouse().KeyDown:connect(function(key)
if (key=="=") then
for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if (v:IsA("Accessory")) then
v.Parent = workspace
end
end
end
end)
end)

drophats1.MouseButton1Click:connect(function()
	game.Players.LocalPlayer:GetMouse().KeyDown:connect(function(key)
if (key=="=") then
for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
if (v:IsA("Accessory")) then
v.Parent = workspace
end
end
end
end)
end)

invisble.MouseButton1Click:connect(function()
	if (game.Players.LocalPlayer.Character.Humanoid.RigType == Enum.HumanoidRigType.R15) then
if (game.Players.LocalPlayer.Character:FindFirstChild("LowerTorso")) then
if (game.Players.LocalPlayer.Character.LowerTorso:FindFirstChild("Root")) then
game.Players.LocalPlayer.Character.LowerTorso.Root:remove()
end
end
else
print("Not R15!")
end
end)

removewaist.MouseButton1Click:connect(function()
	if (game.Players.LocalPlayer.Character.Humanoid.RigType == Enum.HumanoidRigType.R15) then
if (game.Players.LocalPlayer.Character:FindFirstChild("UpperTorso")) then
if (game.Players.LocalPlayer.Character.UpperTorso:FindFirstChild("Waist")) then
game.Players.LocalPlayer.Character.UpperTorso.Waist:remove()
end
end
else
print("Not R15!")
end
end)

shattervest.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/CKbPg9NC", true))()
end)

shattervest1.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/CKbPg9NC", true))()
end)

gabx.MouseButton1Click:connect(function()
	loadstring(game:HttpGet("https://pastebin.com/raw/EntUzD5J", true))();
end)

loadtools.MouseButton1Click:connect(function()
	
for _,v in pairs(game.Players.LocalPlayer:GetChildren()) do
if (v:IsA("Tool")) then
v.Parent = game.Players.LocalPlayer.Backpack
end
end
end)

savetools.MouseButton1Click:connect(function()
	for _,v in pairs(game.Players.LocalPlayer.Backpack:GetChildren()) do
if (v:IsA("Tool")) then
v.Parent = game.Players.LocalPlayer
end
end
end)



print("load one working")


r15gui.Active = true
r6gui.Active = true
toolsgui.Active = true
othersgui.Active = true
othersgui.Draggable = true
r15gui.Draggable = true
r6gui.Draggable = true
toolsgui.Draggable = true

makeinvisble.BackgroundTransparency = 1


	        game:GetService("StarterGui"):SetCore("SendNotification",{
            Title = "Exploit GUI";
            Text = "Press V To Open :))";
        })

function onKeyPress(inputObject, gameProcessedEvent)
	if inputObject.KeyCode == Enum.KeyCode.V then
		    if makeinvisble.Visible == false then
        makeinvisble.Visible = true
    else
        makeinvisble.Visible = false
    end
	end
end
 
game:GetService("UserInputService").InputBegan:connect(onKeyPress)


function zigzag(X) return math.acos(math.cos(X*math.pi))/math.pi end

counter = 0

while wait(0.1)do
	rainbow1.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow2.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow3.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow4.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow5.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow6.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow7.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	rainbow8.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)
	
	counter = counter + 0.01
end

print("load two working")